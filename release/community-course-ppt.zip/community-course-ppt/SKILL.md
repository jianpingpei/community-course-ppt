---
name: community-course-ppt
description: 当用户基于当前仓库的课程材料要求制作课程、做一门课、生成讲课PPT，或把论文和毕设做成课程时使用。读取材料、讨论选题，制作15至20分钟课时的可编辑PPTX、PDF和中文讲稿。适用于天文、地学、社会、生物与科学AI课程。
display_name: 社区课程 PPT
display_name_en: Community Course PPT
description_zh: 根据材料讨论选题并制作科学与AI课程课件
description_en: Plan and build editable science and AI course slides from materials
version: 1.0.0
author: community-course-ppt contributors
---

# 社区课程 PPT

先读材料，再讨论课程。用户已明确主题、受众和课时安排时直接推进。原始材料保留在原处，内容源与交付物分开保存。

## 安装后的使用位置

本skill安装到Agent的用户级skills目录后，在任意课程材料仓库使用。用户说“根据这些材料制作课程”“做一门天文课”“把论文做成讲课PPT”时匹配本skill，也支持显式指定$community-course-ppt。普通商务汇报或只问知识问题时，不强行走课程流程。

SKILL_DIR指当前已加载SKILL.md所在目录，WORKSPACE指用户当前的材料仓库。脚本、模板和依赖从SKILL_DIR读取；材料、课程JSON、素材、来源和成品写入WORKSPACE。不要要求材料仓库包含本工具仓库、skills目录、example目录或templates目录，也不要把用户课件写进skill安装目录。

尊重材料仓库的AGENTS.md与现有组织。未指定课程位置时，可在WORKSPACE/courses/<course-id>/保存course.json、assets、sources.md，成品在其output/。本工具源码仓库里的example仅供参考，不是其他项目的输出位置。先检查原材料，不覆盖或移动用户材料。

## 材料与课程

读取论文、目录、已有PPT、Word及网页，整理覆盖主题、适用受众、可用原图和待核实事实。主题未定时提出3–5个候选，说明学习目标、先修知识和3–4课时安排。批量规划时按学习目标与先修关系去重；用户未要求时不自动批量制作。

模型介绍说明输入、核心方法、输出、典型任务及适用条件。区分基础模型、专用预测器、Agent、工具和数据集。版本、关键结论和性能数字回到原论文；比较保留实验设置。

外部论文综述使用materialType: survey，默认不放校徽、单位、课题号。用户本人的毕设或论文使用own-research，署名只取已确认信息。外部论文与图片在对应页面保留短引，完整来源写入备注。

## 授课设计与图文比例

默认每课时超过20页，通常22–26页，预计15–20分钟；用户明确指定的课程需求优先，样例的24页不作为固定页数。每页都有讲授目的、口语讲稿、秒数和来源，讲稿同时写入PowerPoint备注与Markdown。页数与时间都核对；预计时间与实际试讲时间分开记录。

区分课程与课时：一门课可包含多个课时。各课时封面左上角统一显示课程总名称course.title，主标题显示该课时主题；不自动拼接社区名称或课时序号。

**默认纯讲授，不安排练习、判断题、课堂作业或停下来让学生作答。** includeExercises默认false。用讲解完成的案例、配对解析、计算过程或结果阅读说明方法。用户明确要求互动练习时才启用。

图先承载信息，文字负责解释图中最关键的关系。通常每页一句导读，加1–2条简短解释；不要固定写三大段，也不要只剩关键词。主要概念页优先包含有解释作用的原图、局部放大、原生表格或可编辑科学图解。整套课看图文节奏，避免每页同一种构图。

- 论文图按原始图注选取；先看原图，再决定裁切。复杂多面板拆开讲，不能把整张图缩小后要求听众读小字。
- 一页只讲图里的一个机制或观察结果。用中文说明主要对象、箭头含义和输出；细节移入讲稿。
- 配图优先论文方法图、结构图、实验照片和真实结果图。不用装饰照片或带文字的卡片冒充机制图。
- 原生表格、数据图及教学图解保持可编辑；论文图片保留科学内容与必要标注。不可将课堂计算写成模型实测结果。
- 正文24–30pt，标题32–40pt，关键图注至少20pt，来源短引14–16pt。内容超量先删减、拆页，不缩字号。
- 删除“教学示意、非真实预测、人为构造”等制作说明。直接讲输入、关系和结果，示例来源记录在元信息。保留影响科学结论的必要条件。
- 不用点号把多段解释拼成一长行。说明放在对应图形附近，按阅读顺序组织。
- 对比页按共同维度组织内容。只有“概念、含义、例子”等短内容时，优先用紧凑的可编辑对照表；使用分栏时，让栏标题、分隔线与对应内容靠近、同层对齐。不要用撑满整列高度的文本框垂直居中短标签，造成横线与文字相隔大片空白。
- 按内容关系选图，不把所有内容画成“01、02、03＋竖箭头”。先区分顺序、并列、分支、条件、状态变化、乘积或数据划分，再决定表示。只有确有先后依赖时才用流程箭头；不要让箭头把并列任务误写成连续步骤。重复展示同一机制时可沿用图式，但全课总览需检查是否机械套用了同一种结构，不能只换方向、颜色或形状。

## 模板按课程分配

优先用用户提供的真实PPTX模板，不自行生成模板凑数。读取完整模板，检查封面、图文、流程、比较等实际页面。

**一门课锁定一套，所有课时保持一致；新课优先使用未分配的、已经适配的模板。** courseId和templateId写在课程配置。模板选择同时参考材料仓库的同级课程配置与用户级使用记录；已确定的课程保持templateId不变。记录保存在~/.cache/community-course-ppt/template-usage.json，跨仓库优先推荐少用的可用模板。

本机安装含27套原生模板，网页上传包为满足5 MiB限制只携带一套已适配灰色模板，均位于SKILL_DIR/assets/templates/，catalog.json区分ready与needs-layout-review。灰色、蓝色两套已接入生成器，其余先检查版式再新增profile，不能把“入库”当作“已适配”。模板路径由安装位置解析，不依赖开发机器路径。

```powershell
python "<SKILL_DIR>/scripts/select_template.py" --course "<WORKSPACE>/courses/<course-id>/course.json"
python "<SKILL_DIR>/scripts/select_template.py" --course "<WORKSPACE>/courses/<course-id>/course.json" --set wps-25
```

推荐命令不自动改课件；确定模板后再用--set。默认模板只保存templateId，构建时从当前安装位置找到原生文件，避免在课程配置中固化安装者的用户目录。用户另有模板库时可传--catalog。

模板适配参数见assets/template-profiles.json。新增模板时记录实际封面与正文页号、颜色、标题及页脚位置，并用真实内容导出检查；保留源模板的母版、背景和素材关系，不能只模仿配色。

## 生成与交付

网页端或通过ZIP导入时，先读[网页上传与运行](references/web-upload.md)，检查真实运行环境。跨平台入口为scripts/build_course.py，使用LibreOffice导出PDF；不要求网页端安装PowerPoint。缺少执行工具、依赖或导出器时明确报告，不能将导入成功视为生成成功。

先读[输入格式](references/input-format.md)。课程JSON是内容唯一来源，相对图片路径以该JSON为基准；来源规则见[来源与许可](references/sources-and-license.md)。依赖Node.js 20+、Python 3.10+、PptxGenJS、Pillow与PyMuPDF。安装脚本会安装依赖；缺失时在SKILL_DIR运行npm ci和python -m pip install -r requirements.txt。Windows一键导出需要PowerShell 7+与本机PowerPoint。

在材料仓库工作，使用已安装skill的绝对入口：

```powershell
& "<SKILL_DIR>/scripts/build-course.ps1" -Course "<WORKSPACE>/courses/<course-id>/course.json"
```

该命令在系统临时目录生成、导出、检查，然后更新course.json同目录的output/并清理临时文件。不要依赖当前工作目录切换到工具源码仓库。先完成材料阅读、主题讨论和教案准备；此脚本不会自动读论文生成课程内容。

只生成PPTX或使用其他平台时，可分别调用：

```powershell
node "<SKILL_DIR>/scripts/build.mjs" --course "<WORKSPACE>/courses/<course-id>/course.json" --out "<WORKSPACE>/courses/<course-id>/output"
python "<SKILL_DIR>/scripts/check_pptx.py" "<WORKSPACE>/courses/<course-id>/output" --course "<WORKSPACE>/courses/<course-id>/course.json"
```

默认用templateId解析已安装模板；sourceTemplate仅用于用户自带模板，相对路径以课程JSON为准，也可用CLI的--template和--profile覆盖。生成器先创建可编辑内容，再自动套用原生模板并删除底稿，不要重复套模板。COURSE_PPT_NODE_MODULES可指定离线依赖，COURSE_PPT_PYTHON可指定Python。

论文面板在系统临时目录裁切，结束后删除；原图与来源只保留一份。每门课的output/只保留当前PPTX、PDF、讲稿、总览图、预览、清单和验证摘要，不堆积历史副本。生物专用图解不是通用星图；天文等领域使用对应论文图、真实数据图或按实际关系补充可编辑图解。

## 成品检查

运行结构检查，核对页数、备注、源ID、原生对象、图片、课程模板和15–20分钟预算。纯讲授配置下检查练习残留。用户只要求短预览时才用--preview。

用export-powerpoint.ps1导出最终PPTX为PDF与逐页PNG。逐页看截断、重叠、图注位置、中文换行和论文图里的小字；总览图用于检查全课节奏。修复后重导出受影响课件。其他系统可用LibreOffice与Poppler，明确实际使用的导出工具。

视觉检查还要确认相关内容在空间上成组：标题是否贴近内容，对比项是否对齐，横线是否与所分隔的内容保持联系。异常空白出现时，先核对对象是否存在、文本框尺寸、垂直对齐与位置；不要直接添加无关文字或装饰填空。结构检查能发现越界，不能证明布局的阅读关系正确。

查看整课缩略图，检查图式重复与语义：分支是否被画成串联，公式是否被拆成无意义的步骤，训练与测试的隔离是否可见。窄区域容不下图时改为整页图或拆解内容，不自动退化成编号列表。新增图解必须有当前课程调用，并检查最终PPT中的可编辑对象及讲稿是否一致。

验证通过后更新最终目录，并清理临时渲染。删除前核实绝对路径位于指定输出或临时目录内，不删除课程原始材料。实际发现的问题修入对应脚本或指引，不把特定生物案例写成通用限制。
