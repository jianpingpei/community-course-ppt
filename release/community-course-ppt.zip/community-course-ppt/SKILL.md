---
name: community-course-ppt
description: 根据论文、毕设、资料目录或网页制作科学与AI课程时使用。先理解材料并讨论选题，再自主设计并制作15至20分钟课时的可编辑PPTX、PDF和中文讲稿。适用于天文、地学、社会、生物等课程；支持WorkBuddy SlideP和公开PptxGenJS工具链。
display_name: 社区课程 PPT
display_name_en: Community Course PPT
description_zh: 从材料讨论课程、自主设计并逐页制作科学课件
description_en: Plan, design and build science and AI course slides
version: 2.0.0
author: community-course-ppt contributors
---

# 社区课程 PPT

本skill负责课程教学与设计，不提供固定PPT模板。先理解材料，再确定主题、课时和视觉方案。信息已经明确时直接推进，只问会改变课程的缺失信息。普通商务汇报与单纯知识问答不强行走课程流程。

## 安装后在哪里工作

SKILL_DIR是当前SKILL.md所在目录；WORKSPACE是用户材料工作区。工具从SKILL_DIR读取，课程内容、制作源码与成品留在WORKSPACE。尊重其AGENTS.md，不移动原材料、不把example作为新课程的输出位置。

默认在WORKSPACE/courses/<course-id>/组织course.json、DESIGN.md、assets/与制作源码；output/专门存放当前生成物，会在成功构建后替换，不能放用户原稿。安装后可自然触发，也支持显式指定$community-course-ppt。

## 工作流程

1. **阅读材料与讨论课程**：整理覆盖主题、受众、先修知识、可用原图及证据缺口。主题未定时提出3–5个候选，说明学习目标和3–4课时安排；用户已确定则不重复询问。模型按输入、方法、输出、任务、适用条件解释。
2. **逐页教案**：默认每课时22–26页、15–20分钟、纯讲授，不安排练习。每页记录目的、显示内容、口语讲稿、秒数与来源。不要靠目录、过渡页或缩字凑页数。讲稿同步进备注与Markdown；预计时长与实际试讲时长分开。
3. **课程视觉方案**：先读[设计准则](references/design.md)，编写课程级DESIGN.md。根据材料、受众与科学对象选择字体、颜色、内容区和构图。同课各课时共用设计，新课重新决定；不默认沿用任何样例。若工作区已有其他课程，比较其设计，避免仅换颜色。
4. **选择实际可用的制作路线**：优先SlideP，详见[SlideP流程](references/slidep.md)；否则使用[PptxGenJS流程](references/pptxgenjs.md)。先检查能力再写页面，不在缺少SlideP服务时继续假装写入。构建中切换引擎要重新生成整门课，不能混合两条路线的页面。
5. **逐页制作与检查**：先核对所用图，再排版。完成一页就检查内容、布局和资源，真实问题修好后继续。读取[检查与交付](references/quality.md)，最终核对整课节奏、成品文件与时间预算。结构通过不代表视觉已检查。

## 科学课件的硬要求

- 正文24–30pt，标题32–40pt，关键图注至少20pt，来源短引14–16pt；SlideP使用px时须检查最终PPTX实际字号，不能直接照搬px数值。放不下就删减、拆页或换构图。
- 图要解释关系或提供证据。优先论文方法图、真实结果、材料原图、数据图和可编辑科学图解；复杂论文图按面板拆解，不整张缩小。禁止用装饰卡、编号箭头或生成图片替代科学证据。
- 图解区分并列、先后、分支、层级、空间与统计关系。只在确有依赖时画流程箭头。允许连续讲解沿用图式，禁止整课机械复制一种构图。
- 图旁文字贴近相应对象，不把说明用点号拼成一长行。容器贴合内容，空元素整组删除，不拉高文本框或拉大间距填空。
- 外部资料使用materialType: survey，默认无校徽、机构、课题号。本人研究用own-research，仅使用已确认署名。外部论文和图片保留作者及来源，见[来源规则](references/sources-and-license.md)。
- 四课时属于一门课：封面左上角显示course.title，主标题为该课时主题，不自动拼社区和课时序号。
- 不出现“教学示意、非真实预测、人为构造”等制作话术；算例来源在元信息中说明，科学结论必需的条件仍保留。
- 用户自带PPTX模板时先分析原稿，再映射源页并保留分组与主视觉；这不是任意模板的自动套用承诺。没有自带模板时自主设计，不寻找内置模板ID。

## 构建入口

先读[输入约定](references/input-format.md)。Agent先完成材料理解、设计与页面制作源码；构建脚本不自动读论文或自动设计。

```sh
python "<SKILL_DIR>/scripts/build_course.py" --course "<WORKSPACE>/courses/<id>/course.json" --engine auto
```

auto会检查SlideP命令、版本、帮助与实际创建请求；不可用时在生成前选择公开路线。可显式指定slidep或pptxgenjs。Windows默认PowerPoint导出，其他平台默认LibreOffice；可用--renderer选择，--soffice指定路径。Windows的build-course.ps1是同一入口的薄包装。

在WorkBuddy中使用已有Node/SlideP/服务能力，不从内部源安装或分发腾讯包。不要求SlideP用户额外安装PptxGenJS依赖。通用路线依赖安装按实际需要执行；[网页上传与试用](references/web-upload.md)区分导入、生成、导出和真实验收。

只有用户明确接受缺少PDF时才传--pptx-only；短样稿才传--preview。最终验证摘要必须准确记录引擎、导出工具及尚未完成的检查。用户通过预览看到了文件，不等于Agent已做视觉验收。
